Existing PCB1 design export dated 2026-06-26. Original geometry and drill data retained. See the repository hardware guide before ordering.
已有 PCB1 设计导出，2026-06-26。保留原几何与钻孔数据，下单前阅读仓库硬件指南。
